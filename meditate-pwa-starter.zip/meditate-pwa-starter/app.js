
// Register service worker
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./service-worker.js');
  });
}

// DOM helpers
const $ = sel => document.querySelector(sel);

// State
let sessions = [];
let current = null;
let audio = new Audio();
audio.preload = 'auto';

// Load sessions
async function loadSessions() {
  const res = await fetch('sessions.json');
  sessions = await res.json();
  const list = document.getElementById('sessionList');
  list.innerHTML = '';
  sessions.forEach(s => {
    const li = document.createElement('li');
    li.innerHTML = `<span>${s.title} · ${s.length_min} min</span>
      <span><button data-play="${s.id}">Play</button></span>`;
    list.appendChild(li);
  });
}

// Play handling
function setNowPlaying(s) {
  document.getElementById('nowPlaying').textContent = s ? s.title : '—';
  document.getElementById('timeRemaining').textContent = '';
  document.getElementById('offlineToggle').checked = false;
  current = s;
}

function formatTime(sec) {
  const m = Math.floor(sec/60);
  const s = Math.floor(sec%60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

function tick() {
  if (audio && !audio.paused) {
    const remaining = Math.max(0, (audio.duration || 0) - audio.currentTime);
    document.getElementById('timeRemaining').textContent = remaining ? `• ${formatTime(remaining)} left` : '';
    requestAnimationFrame(tick);
  }
}

async function playSessionById(id) {
  const s = sessions.find(x => x.id === id);
  if (!s) return;
  setNowPlaying(s);
  audio.src = s.file;
  await audio.play();
  document.getElementById('playPause').textContent = 'Pause';
  requestAnimationFrame(tick);
}

document.getElementById('sessionList').addEventListener('click', (e) => {
  const btn = e.target.closest('button[data-play]');
  if (!btn) return;
  playSessionById(btn.dataset.play);
});

document.getElementById('quickPlay').addEventListener('click', () => playSessionById('quick-3'));

document.getElementById('playPause').addEventListener('click', async () => {
  if (!current) return;
  if (audio.paused) {
    await audio.play();
    document.getElementById('playPause').textContent = 'Pause';
    requestAnimationFrame(tick);
  } else {
    audio.pause();
    document.getElementById('playPause').textContent = 'Play';
  }
});

// Streak + minutes
function getStats() {
  const stats = JSON.parse(localStorage.getItem('stats') || '{}');
  return { streak: stats.streak||0, minutes: stats.minutes||0, lastDay: stats.lastDay||null };
}
function setStats(s) {
  localStorage.setItem('stats', JSON.stringify(s));
  document.getElementById('streak').textContent = s.streak;
  document.getElementById('minutes').textContent = s.minutes;
}

audio.addEventListener('ended', () => {
  const now = new Date();
  const day = now.toISOString().slice(0,10);
  const st = getStats();
  if (st.lastDay !== day) {
    const prev = st.lastDay ? new Date(st.lastDay) : null;
    let newStreak = st.streak || 0;
    if (prev) {
      const diff = (now - new Date(st.lastDay)) / (1000*60*60*24);
      newStreak = (diff <= 2) ? newStreak + 1 : 1;
    } else {
      newStreak = 1;
    }
    st.streak = newStreak;
    st.lastDay = day;
  }
  st.minutes = Math.round((st.minutes||0) + (current?.length_min||0));
  setStats(st);
});

// Offline toggle: cache/un-cache current session file
document.getElementById('offlineToggle').addEventListener('change', async (e) => {
  if (!current) { e.target.checked = false; return; }
  const cache = await caches.open('calmstart-audio-v1');
  if (e.target.checked) {
    await cache.add(current.file);
  } else {
    await cache.delete(current.file);
  }
});

// Simple onboarding (time-only)
const ONBOARDED = 'onboarded';
function showOnboardingIfNeeded() {
  const done = localStorage.getItem(ONBOARDED);
  document.getElementById('onboarding').classList.toggle('hidden', !!done);
}
document.getElementById('saveOnboarding').addEventListener('click', () => {
  const time = document.getElementById('reminderTime').value;
  localStorage.setItem('reminderTime', time || '');
  localStorage.setItem(ONBOARDED, '1');
  document.getElementById('onboarding').classList.add('hidden');
  alert('Saved. Tip: add a daily phone reminder at your chosen time.');
});

// Install prompt
let deferredPrompt = null;
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  document.getElementById('installBtn').hidden = false;
});
document.getElementById('installBtn').addEventListener('click', async () => {
  if (!deferredPrompt) return;
  deferredPrompt.prompt();
  await deferredPrompt.userChoice;
  document.getElementById('installBtn').hidden = true;
});

// Init
(async function init() {
  await loadSessions();
  const st = getStats();
  setStats(st);
  showOnboardingIfNeeded();
})();
